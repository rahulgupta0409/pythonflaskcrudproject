from datetime import datetime
from flask import Flask, render_template , request, redirect
from flask.wrappers import Request
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

from werkzeug.utils import redirect 

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tilak.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Tilak(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    emp_name = db.Column(db.String(200), nullable=False)   
    emp_degn = db.Column(db.String(500), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"{self.sno} - {self.emp_name}"

@app.route("/", methods=['GET','POST'])
def hello_world():
    if request.method=='POST':
        emp_name = request.form['emp_name']
        emp_degn = request.form['emp_degn']

        tilak = Tilak(emp_name=emp_name, emp_degn=emp_degn)
        db.session.add(tilak)
        db.session.commit()

    allTilak = Tilak.query.all()
    return render_template('index.html', allTilak=allTilak)

@app.route("/about/")
def about():
    return render_template("/about.html")

@app.route("/update/<int:sno>", methods=['GET','POST'])
def update(sno):
    if request.method == "POST":
        emp_name = request.form['emp_name']
        emp_degn = request.form['emp_degn']
        allTilak = Tilak.query.filter_by(sno=sno).first()
        allTilak.emp_name = emp_name 
        allTilak.emp_degn = emp_degn 
        db.session.add(allTilak)
        db.session.commit()
        return redirect("/")

    allTilak = Tilak.query.filter_by(sno=sno).first()
    return render_template('update.html', allTilak=allTilak)

@app.route("/delete/<int:sno>")
def delete(sno):
    allTilak = Tilak.query.filter_by(sno=sno).first()
    db.session.delete(allTilak)
    db.session.commit()

    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True, port=8000)